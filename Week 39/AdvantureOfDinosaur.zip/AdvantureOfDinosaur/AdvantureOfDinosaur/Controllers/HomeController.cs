﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdvantureOfDinosaur.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Records()
        {
            ViewBag.Message = "Your records page.";

            // Let's read from the database instead hardcoding these values:
            List<string> records = new List<string>();
            records.Add("Blabla, easy, 100");
            records.Add("Blabla, easy, 90");
            records.Add("Blabla, easy, 80");
            records.Add("Blabla, easy, 75");
            records.Add("Blabla, easy, 60");

            ViewBag.Records = records;

            return View();
        }
    }
}